GSE21477 primary 39-array provenance bundle
Recovered on 2026-11-11 from the user's prior analysis files and validated archive records.

Files:
- GSE21477_sourceID_blocked_limma_v2.R: original primary analysis workflow; downloads the GEO raw archive, maps all 39 GSMs, computes a common 39-array RMA matrix, fits separate source-ID fixed-effect limma models in ES1/ES2/ES3, and runs global nested, global unblocked, and within-block RMA sensitivity models.
- sessionInfo.txt: archived R 4.6.2 execution environment from the historical primary-analysis output archive.
- GSE21477_RAWCEL_MD5_revalidation_v1.csv: independently recomputed uncompressed CEL MD5 values for all 39 CEL.GZ members in GSE21477_RAW.tar, compared with the historical R-run manifest.
- GSE21477_Primary_39CEL_Provenance_Revalidation_v1.txt: archive hash, counts, runtime, and interpretation boundary.

Independent raw-file check:
- GSE21477_RAW.tar SHA-256: bdba01b446ce63730134847e49d839da74400f6066cfc839541de903fc5b7f83
- 39 TAR members; 39 unique GSMs; 39 nested gzip streams decompressed; 39/39 uncompressed CEL MD5 values match the archived R-run manifest.
- The historical statistical audit archive contains the nine primary contrast topTable outputs, global nested and unblocked sensitivity outputs, within-block RMA sensitivity outputs, RLE/NUSE and PCA QC outputs, and sessionInfo.
- This validates raw-file identity and recovers the historical execution record. It does not claim a new independent RMA/limma rerun in the current Deepnote project.
