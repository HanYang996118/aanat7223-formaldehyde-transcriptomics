AANAT7223 Reviewer #1 reconciliation outputs — V26.0

1. DataS2_Table2_15Contrast_Reconciliation.csv: V25.6 Data S2 was counted against its 15-contrast audit. All 15 counts and all 15 >=1.5-fold counts match the audit.
2. S1A_AllTested_GO_BP_Terms_V26_0.csv.gz: all eligible GO-BP terms (10–500 mapped background genes) are tested for every non-empty contrast × direction. BH correction is applied across the complete eligible term family, including zero, one or two overlaps.
3. S1A_Significant_GO_BP_Terms_V26_0.csv and S1A_GO_BP_Testing_Family_Summary_V26_0.csv: complete FDR-significant term list and all 45 contrast × direction status rows. Empty selected-gene sets are marked not tested.
4. Rat_2ppm_Matched_Gene_Inputs_V26_0.csv.gz: 11,176 shared one-to-one genes for each rat comparison, with signed log2FC and moderated t statistics from exposed-minus-control contrasts.
5. GSE21477_Sample_to_Group_Map_V26_0.csv: all 39 GEO samples mapped using GEO title/source metadata, not Series Matrix column positions; includes block, source ID, biological replicate label, condition, and matched control GSM.
6. Rat_Nasal_Tissue_Source_Audit_V26_0.csv: source-level nasal sampling descriptions and limits for GSM570620 and GSM1150937.

The original GSE21477 primary statistical results remain recovered/provenance-validated historical results. This audit reconstructs sample assignments from GEO metadata and does not claim a new 39-array RMA/limma rerun.
